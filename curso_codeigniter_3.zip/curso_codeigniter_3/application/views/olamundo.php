<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $mensagem ?></title>
</head>
<body>
    <h1><?php echo $mensagem ?></h1>
</body>
</html>