<?php
//tem que estar em todos com arquivos
defined('BASEPATH') OR exit('No direct script access allowed');

// nome da classe mesmo do arquivo e primeira letra maiscula
class Categorias extends CI_Controller {
    
	public function __construct(){
		parent::__construct();
		$this->load->model('categorias_model','modelcategorias');
		$this->categorias = $this->modelcategorias->listar_categorias();
	}
	
	public function index($id,$nome,$pular=null,$post_por_pagina=null)
	{
		
		$this->load->library('pagination');
		
		$this->load->model('publicacoes_model','modelpublicacao');

		$config['base_url'] = base_url("categoria/".$id."/".$nome);
		$config['total_rows'] = $this->modelpublicacao->contar1($id);
		$post_por_pagina = 5;
		$config['per_page'] = $post_por_pagina;

		$this->pagination->initialize($config);

		$dados['link_paginacao'] = $this->pagination->create_links();


		$dados['categorias'] = $this->categorias;
		$this->load->model('publicacoes_model','modelpublicacoes');
		$dados['postagem'] = $this->modelpublicacoes->categoria_pub($id,$pular,$post_por_pagina);
		

		$dados['titulo'] = 'Categorias';
		$dados['subtitulo'] = '';
        $dados['subtitulodb'] = $this->modelcategorias->listar_titulo($id);

		
		$this->load->view('frontend/template/html-header', $dados);
		$this->load->view('frontend/template/header');
		$this->load->view('frontend/categoria');
		$this->load->view('frontend/template/aside');
		$this->load->view('frontend/template/footer');
		$this->load->view('frontend/template/html-footer');
	}

}