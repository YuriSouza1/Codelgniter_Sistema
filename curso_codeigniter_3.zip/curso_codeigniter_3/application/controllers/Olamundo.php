<?php
//tem que estar em todos com arquivos
defined('BASEPATH') OR exit('No direct script access allowed');

// nome da classe mesmo do arquivo e primeira letra maiscula
class Olamundo extends CI_Controller {
    //metodo
	public function index()
	{
		$dados['mensagem']= 'Ola Mundo!'; //variavel
		$this->load->view('olamundo', $dados); //nome da view entre ()
	}

	public function teste()
	{
		$dados['mensagem']= 'Testando!'; //variavel
		$this->load->view('olamundo', $dados); //nome da view entre ()
	}

	public function testedb()
	{
		$dados['mensagem']= $this->db->get('postagens')->result();
		echo "<pre>";
		print_r($dados);
	}
}