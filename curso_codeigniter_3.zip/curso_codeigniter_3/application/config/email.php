<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol']='mail';
$config['charset']='utf-8';
$config['mailtype']='html';
$config['wordwrap']=TRUE;
$config['newline']='\r\n';
$config['mailtype']='html';